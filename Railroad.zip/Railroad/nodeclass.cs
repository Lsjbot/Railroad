﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Railroad
{
    class nodeclass
    {
        public static int nodecount = 0;

        public int ID;
        public Point mapsquare;
        Boolean active = true;
        public nodetypeclass nodetype;

        public List<int> outedge = new List<int>();
        public List<int> inedge = new List<int>();

        public nodeclass(Point msq)
        {
            mapsquare = msq;
        }

        public List<string> sides(bool incoming)
        {
            if (incoming)
                return nodetype.inconn;
            else
                return nodetype.outconn;
        }

        public void addedge(int iedge,Boolean incoming)
        {
            if (incoming)
                inedge.Add(iedge);
            else
                outedge.Add(iedge);
        }
    }
}
