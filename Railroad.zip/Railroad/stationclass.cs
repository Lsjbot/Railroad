﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Railroad
{
    public class stationclass
    {
        public static Dictionary<string, stationclass> stationdict = new Dictionary<string, stationclass>();
        public int stationmapsize = 25;
        public string name;
        public mapclass stationmap;
        Point location;

        public stationclass(string namepar,Point locpar,mapclass mainmap)
        {
            if (!String.IsNullOrEmpty(namepar))
                name = namepar;
            else
                name = "Station " + (stationdict.Count + 1).ToString();
            location = locpar;
            stationmap = new mapclass(stationmapsize);
            stationmap.flatmap(terrainclass.terraindict["Sand"]);
            stationmap.maptype = mapclass.stationmaptype;

            switch (mainmap.sq[location.X,location.Y].rail.pattern)
            {
                case "W,E":
                case "E,W":
                    int y0 = stationmapsize / 2;
                    stationmap.addrail(new Point(0, y0), railclass.find_by_pattern("W,E.W,SE"));
                    stationmap.addrail(new Point(stationmapsize-1, y0), railclass.find_by_pattern("E,W.E,SW"));
                    for (int i = 1; i < stationmapsize-1; i++)
                        stationmap.addrail(new Point(i,y0),mainmap.sq[location.X, location.Y].rail);
                    stationmap.addrail(new Point(1, y0+1), railclass.find_by_pattern("NW,E"));
                    stationmap.addrail(new Point(stationmapsize-2, y0 + 1), railclass.find_by_pattern("W,NE"));
                    for (int i = 2; i < stationmapsize - 2; i++)
                        stationmap.addrail(new Point(i, y0+1), mainmap.sq[location.X, location.Y].rail);

                    break;

            }
        }
    }
}
