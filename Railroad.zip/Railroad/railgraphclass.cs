﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QuikGraph;
using System.Drawing;

namespace Railroad
{
    class railgraphclass
    {
        public static Dictionary<int, nodeclass> nodedict = new Dictionary<int, nodeclass>();
        public static Dictionary<int, edgeclass> edgedict = new Dictionary<int, edgeclass>();
        public void test()
        {
            //var graph = new AdjacencyGraph<Point,Edge<Point>>();

        }

        public static int addnode(nodeclass newnode)
        {
            int id = nodedict.Count + 1;
            nodedict.Add(id, newnode);
            return id;
        }

        public static void removenode(int inode, mapclass map)
        {
            foreach (int nedge in nodedict[inode].inedge)
                removeedge(nedge, map);
            foreach (int nedge in nodedict[inode].outedge)
                removeedge(nedge, map);
            map.sq[nodedict[inode].mapsquare.X, nodedict[inode].mapsquare.Y].nodelist.Remove(inode);
            nodedict.Remove(inode);
        }

        public static int addedge(int fromnode, int tonode, int sidenode, string side, mapclass map)
        {
            int id = edgedict.Count + 1;
            edgeclass newedge = new edgeclass();
            newedge.ID = id;
            newedge.fromnode = fromnode;
            newedge.tonode = tonode;
            newedge.sidenode = sidenode;
            newedge.side = side;
            edgedict.Add(id, newedge);
            nodedict[fromnode].addedge(id, false);
            nodedict[tonode].addedge(id, true);
            bool incoming = (tonode == sidenode);
            map.follow_track_to_node(nodedict[sidenode].mapsquare,side, incoming,newedge.ID);
            return id;
        }

        public static void removeedge(int nedge, mapclass map)
        {
            nodedict[edgedict[nedge].fromnode].outedge.Remove(nedge);
            nodedict[edgedict[nedge].tonode].inedge.Remove(nedge);
            bool incoming = (edgedict[nedge].tonode == edgedict[nedge].sidenode);
            map.follow_track_to_node(nodedict[edgedict[nedge].sidenode].mapsquare, edgedict[nedge].side, incoming, -edgedict[nedge].ID);

            edgedict.Remove(nedge);
        }
    }
}
