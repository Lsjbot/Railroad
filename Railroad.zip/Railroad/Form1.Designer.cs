﻿namespace Railroad
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainmapbutton = new System.Windows.Forms.Button();
            this.railselectbutton = new System.Windows.Forms.Button();
            this.bitmapbutton = new System.Windows.Forms.Button();
            this.nodedisplaybutton = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.mapgeneratorbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mainmapbutton
            // 
            this.mainmapbutton.Location = new System.Drawing.Point(639, 245);
            this.mainmapbutton.Name = "mainmapbutton";
            this.mainmapbutton.Size = new System.Drawing.Size(110, 23);
            this.mainmapbutton.TabIndex = 0;
            this.mainmapbutton.Text = "Show main map";
            this.mainmapbutton.UseVisualStyleBackColor = true;
            this.mainmapbutton.Click += new System.EventHandler(this.mainmapbutton_Click);
            // 
            // railselectbutton
            // 
            this.railselectbutton.Location = new System.Drawing.Point(639, 288);
            this.railselectbutton.Name = "railselectbutton";
            this.railselectbutton.Size = new System.Drawing.Size(110, 23);
            this.railselectbutton.TabIndex = 1;
            this.railselectbutton.Text = "Show railselect";
            this.railselectbutton.UseVisualStyleBackColor = true;
            this.railselectbutton.Click += new System.EventHandler(this.railselectbutton_Click);
            // 
            // bitmapbutton
            // 
            this.bitmapbutton.Location = new System.Drawing.Point(639, 342);
            this.bitmapbutton.Name = "bitmapbutton";
            this.bitmapbutton.Size = new System.Drawing.Size(110, 23);
            this.bitmapbutton.TabIndex = 2;
            this.bitmapbutton.Text = "Fix bitmaps";
            this.bitmapbutton.UseVisualStyleBackColor = true;
            this.bitmapbutton.Click += new System.EventHandler(this.bitmapbutton_Click);
            // 
            // nodedisplaybutton
            // 
            this.nodedisplaybutton.Location = new System.Drawing.Point(639, 396);
            this.nodedisplaybutton.Name = "nodedisplaybutton";
            this.nodedisplaybutton.Size = new System.Drawing.Size(110, 37);
            this.nodedisplaybutton.TabIndex = 3;
            this.nodedisplaybutton.Text = "List nodes and edges";
            this.nodedisplaybutton.UseVisualStyleBackColor = true;
            this.nodedisplaybutton.Click += new System.EventHandler(this.nodedisplaybutton_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(37, 49);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(368, 262);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // mapgeneratorbutton
            // 
            this.mapgeneratorbutton.Location = new System.Drawing.Point(639, 195);
            this.mapgeneratorbutton.Name = "mapgeneratorbutton";
            this.mapgeneratorbutton.Size = new System.Drawing.Size(110, 23);
            this.mapgeneratorbutton.TabIndex = 5;
            this.mapgeneratorbutton.Text = "Map generator";
            this.mapgeneratorbutton.UseVisualStyleBackColor = true;
            this.mapgeneratorbutton.Click += new System.EventHandler(this.mapgeneratorbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 671);
            this.Controls.Add(this.mapgeneratorbutton);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.nodedisplaybutton);
            this.Controls.Add(this.bitmapbutton);
            this.Controls.Add(this.railselectbutton);
            this.Controls.Add(this.mainmapbutton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button mainmapbutton;
        private System.Windows.Forms.Button railselectbutton;
        private System.Windows.Forms.Button bitmapbutton;
        private System.Windows.Forms.Button nodedisplaybutton;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button mapgeneratorbutton;
    }
}

