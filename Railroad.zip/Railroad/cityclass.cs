﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Railroad
{
    public class cityclass
    {
        public string name = "";
        public double lat = 0;
        public double lon = 0;
        public long population = 0;
        public int elevation = 0;
        public string gntype = "";
    }
}
