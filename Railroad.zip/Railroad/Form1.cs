﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railroad
{
    public partial class Form1 : Form
    {
        public static string railroadfolder = @"I:\railroad\";
        public static string extractdir = @"I:\dotnwb3\extract\";
        mapclass map = null;
        public Form1()
        {
            InitializeComponent();

            terrainclass.init_terrains();
            railclass.initrails();

            //map = new mapclass(128);
        }

        private void mainmapbutton_Click(object sender, EventArgs e)
        {
            if (map == null)
                mapgeneratorbutton_Click(sender, e);
            map.maptype = mapclass.mainmaptype;
            //map.randommap();
            FormMainmap mm = new FormMainmap(map,"Main map");
            mm.Show();
        }

        private void railselectbutton_Click(object sender, EventArgs e)
        {
            FormRailselect fr = new FormRailselect();
            fr.Show();
        }

        private void bitmapbutton_Click(object sender, EventArgs e)
        {
            railclass.prepare_bitmap_files(@"I:\railpics\");
            railselectbutton_Click(sender, e);
        }

        public void memo(string s)
        {
            richTextBox1.AppendText(s + "\n");
            richTextBox1.ScrollToCaret();
        }

        private void nodedisplaybutton_Click(object sender, EventArgs e)
        {
            memo("Nodes:");
            foreach (int inode in railgraphclass.nodedict.Keys)
            {
                string s = inode + ": " + railgraphclass.nodedict[inode].mapsquare.X+","+ railgraphclass.nodedict[inode].mapsquare.Y + "; in: ";
                foreach (int i in railgraphclass.nodedict[inode].inedge)
                    s += " " + i;
                s += "; out: ";
                foreach (int i in railgraphclass.nodedict[inode].outedge)
                    s += " " + i;
                memo(s);
            }
            memo("Edges:");
            foreach (int iedge in railgraphclass.edgedict.Keys)
            {
                string s = iedge + ": " + railgraphclass.edgedict[iedge].fromnode + " -> " + railgraphclass.edgedict[iedge].tonode;
                memo(s);
            }
        }

        private void mapgeneratorbutton_Click(object sender, EventArgs e)
        {
            FormMapgenerator fmg = new FormMapgenerator();
            fmg.ShowDialog();
            map = fmg.newmap;
        }
    }
}
