﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Railroad
{
    public class nodetypeclass
    {
        public List<string> outconn = new List<string>();
        public List<string> inconn = new List<string>();

    }
}
