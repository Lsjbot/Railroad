﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Railroad
{
    public class carclass
    {
        public cartypeclass cartype;
        public cargoclass cargo;
        public Point cargoorigin; 
        public double weight;
    }
}
