﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Railroad
{
    public class cargoclass
    {
        public string cargoname = "";
        public double carloadweight = 0;

    }
}
